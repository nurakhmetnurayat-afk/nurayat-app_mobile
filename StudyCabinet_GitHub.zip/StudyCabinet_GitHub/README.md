# Study Cabinet — React Native / Expo

Учебное мобильное приложение с экранами входа, подтверждения кода, главной страницей, каталогом предметов, деталями задания и профилем.

## Требования

- Node.js LTS
- npm
- Expo Go на телефоне (если запускаете на физическом устройстве)

## Запуск в VS Code

1. Распакуйте проект и откройте папку `StudyCabinet_GitHub` в VS Code.
2. Откройте Terminal → New Terminal.
3. Установите зависимости:

   ```bash
   npm install
   ```

4. Запустите Expo:

   ```bash
   npx expo start
   ```

5. Отсканируйте QR-код приложением Expo Go или используйте эмулятор.

## GitHub

1. Создайте новый пустой репозиторий на GitHub.
2. Откройте терминал внутри папки проекта.
3. Выполните команды, заменив ссылку на адрес своего репозитория:

   ```bash
   git init
   git add .
   git commit -m "Add Study Cabinet React Native app"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
   git push -u origin main
   ```

## Важно

- Экран OTP — демонстрационный: приложение не отправляет настоящее SMS и не проверяет введённый код.
- Данные предметов и профиля пока демонстрационные.
- Папка `node_modules` не нужна для GitHub: она установится командой `npm install`.
